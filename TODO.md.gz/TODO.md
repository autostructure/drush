- Allow installation of drush 5.
  - with pear?    -> hard dependency on a puppet pear module?
  - from tarball? -> for any version of drush. example42/puppi may help?

- Fix version management.
  - Alias 7 to master / dev-master

